package br.com.davesmartins.nutriweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutriWebNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
